BLOCK RAIDEN 0.1.0 ALPHA
A Steve character mod for Metal Gear Rising: Revengeance (Windows PC / Steam)

NOT AN OFFICIAL MINECRAFT PRODUCT. NOT APPROVED BY OR ASSOCIATED WITH MOJANG
OR MICROSOFT. Not affiliated with Konami or PlatinumGames.

WHAT THIS RELEASE DOES
Replaces the playable prologue, default cyborg, story suit, and Mariachi bodies
with a segmented Steve character, adds a forearm shield, and replaces the
prologue/standard sword and final Murasama with a voxel diamond sword.
Combat uses Rising's existing mechanics. The shield follows the original
guard/parry animation; it does not add independent shield collision or a new
shield button. No block placement/building is included. Other optional costumes
and weapons keep their original appearance. Prerecorded cutscenes, portraits,
menu artwork, voices, and character names still show or refer to Raiden.

REQUIREMENTS
- Windows 10/11, 64-bit x86 PC.
- Your own installed Steam PC copy of Metal Gear Rising: Revengeance, with the
  game archives matching this release. Different builds are rejected before
  game files are changed.
- Your own installed Minecraft Java Edition 1.21.11 client. Run that version
  once through your Minecraft launcher so its client JAR is installed.
  Other Java versions are accepted only if all three required textures match.
  A Bedrock-only installation does not supply the required Java textures.
- No separate Python, Blender, mod loader, or internet connection is required
  to run this package. A small portable runtime is included.

INSTALL
1. Extract the whole ZIP into a normal folder. Do not run inside the ZIP.
2. Close Rising. Double-click Install.cmd.
3. The installer searches Steam libraries and the usual Minecraft Java folder.
   If it cannot locate them, paste the requested game folder or client JAR path.
4. Wait for "Installed and verified 26 files". Launch Play.cmd or use Steam.
5. Use the default costume and standard HF Blade for the main story.

The installer rebuilds the mod locally from your own game assets. It installs
26 loose DAT/DTT files under GameData\pl. It does not edit the game executable,
CPK archives, movies, or saves. Existing loose files are backed up first under
%LOCALAPPDATA%\BlockRaidenMod\<game-folder-id>. Keep those backups.
If the game is in a protected folder and Windows denies access, rerun the CMD
as administrator. Administrative privileges are not requested automatically.

PARRY
Use Rising's ordinary parry: push toward an incoming attack and press light
attack at the correct time. With default PC controls, light attack is the left
mouse button. A left-arm-removal story scene also removes the attached shield.

VERIFY OR UNINSTALL
Close the game, then double-click Verify.cmd to check installed file hashes.
Double-click Uninstall.cmd to remove this mod and restore backed-up loose files.
Uninstall refuses to overwrite files changed by a later mod. If that happens,
first remove the later mod or restore this release's files, then retry.
An interrupted install/uninstall can be recovered by running Uninstall.cmd.
Backups remain available after uninstall. Reinstall uses Install.cmd again.

CUSTOM INSTALL LOCATIONS
From a command prompt in this extracted folder:
  Install.cmd --game-dir "E:\Games\METAL GEAR RISING REVENGEANCE" --minecraft-jar "E:\Minecraft\versions\1.21.11\1.21.11.jar"
  Uninstall.cmd --game-dir "E:\Games\METAL GEAR RISING REVENGEANCE"

If automatic discovery cannot find a custom launcher, point to its installed
1.21.11 client JAR. This installer does not download either game or bypass DRM.

VERIFICATION AND LIMITATIONS
The local mod was observed in the opening R-00 battle. Structural validation
passed, and the shield's orientation was checked with the game's guard animation
in Blender. A complete campaign playthrough, successful live sword hits, and a
successful live shield parry remain unverified. Automated combat inputs were
unreliable. This is an alpha release, not a verified full-campaign completion.
The package builder and install/rollback checks are documented in VALIDATION.txt.

SHARING
Share the original Block-Raiden-0.1.0-alpha.zip, not your installed GameData
folder, generated mod files, backup folder, saves, Minecraft JAR, or game files.
The ZIP contains model changes and installation code, plus licensed runtime
dependencies. Original Rising archives/models/animations/movies and Minecraft
texture files are not supplied; recipients supply their own installed copies.
Do not sell this fan mod or present it as an official product.

SOURCE AND CREDITS
Installer source is in scripts; model changes are in patches. Original geometry
was authored for this mod using the MGR2Blender2MGR workflow:
https://github.com/Gaming-With-Portals/MGR2Blender2MGR
The Blender add-on is not bundled. The portable installer uses an independently
implemented CRILAYLA reader, DAT repacker, and copy/literal patch format.
Format references:
https://github.com/kamikat/cpktools/blob/master/cpk/crilayla.py
Minecraft terms and usage guidelines:
https://www.minecraft.net/en-us/eula
https://www.minecraft.net/en-us/usage-guidelines
Original scripts and model modifications: see LICENSE.txt.
Bundled runtime components: see THIRD-PARTY-NOTICES.txt.

Contact the person who shared this ZIP for support.
