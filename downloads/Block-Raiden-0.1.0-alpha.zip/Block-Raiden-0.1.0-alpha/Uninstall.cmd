@echo off
"%~dp0runtime\python.exe" "%~dp0scripts\mod_manager.py" uninstall %*
set "result=%errorlevel%"
pause
exit /b %result%
