@echo off
"%~dp0runtime\python.exe" "%~dp0scripts\mod_manager.py" install %*
set "result=%errorlevel%"
pause
exit /b %result%
